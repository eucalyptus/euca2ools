"""ZSmime.__init__

Copyright (c) 2000 Ng Pheng Siong. All rights reserved.
This software is released under the ZPL. Usual disclaimers apply."""

__version__='1.1'

import SmimeTag

